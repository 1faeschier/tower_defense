package Model;

public interface AUnePlace {
    Position getPosition();
}