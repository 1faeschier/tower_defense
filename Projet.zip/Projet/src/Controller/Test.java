package Controller;

import Model.*;
import View.Map;

import java.util.ArrayList;
import java.util.Scanner;
import java.io.BufferedReader;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;

public class Test {

    public static int conteur = 0;
    public static ArrayList<Ennemie> listenemie = new ArrayList<>();
    public static ArrayList<Defence>listdefence = new ArrayList<>();
    static Wave wave1 = new Wave();
    public static int gold = 30;
    static int speed = 5;
    static boolean gameOver = false;
    public static int map = 1;
    public static Way way;
    public boolean posetoursimple = false;
    boolean posetourgele = false;
    static boolean upgradetour = false;
    private static Defence tower;
    private static int difficulte;
    public static int PV = 10;
    public static int wavelevel = 1;
    public static boolean waveIsFinished = false;
    public static int play = 0;
    public static int Bestres;



    public static void start() {
        menuStart();
        Map.create();
    }


    public static void menuStart() {
        System.out.println("Bonjour, l'équipe AN vous souhaite une excellent partie ");
        Scanner in1 = new Scanner(System.in);
        System.out.print("Choisir une carte (1 ou 2) ");
        //String mapstring = in1.nextLine(); map = Integer.parseInt(mapstring);
        map = 1;
        Scanner in2 = new Scanner(System.in);
        System.out.print("choisir une difficulté (1-10) ");
        //String difficulteStr = in2.nextLine(); difficulte = Integer.parseInt(difficulteStr);
        difficulte = 2;
        PV = 10;
        way = new Way();
        Map.way = way; Map.map = 1;
        listenemie = wave1.start(1);
        Map.setListenemie(listenemie);
        Bestres = load("save.tmp");
    }

    public static void pause(){
        for (Ennemie e : listenemie){
            e.pause();
        }
        for (Defence t : listdefence){
            t.pause();
        }
        if(play == 1){play = 0;}
        else {play = 1;}
    }

    public static void begin(){
        for (Defence t : listdefence) {
            t.start(listenemie);
        }
        for (Ennemie e : listenemie){
            e.start(listenemie, way, map);
        }
    }

    public static void upgradetour() {
        if (gold > tower.getpriceupgrade()){
            tower.upgrade();
            gold -= tower.getpriceupgrade();
        }
        else{
            System.out.println("pas assez d'argent");
        }
        upgradetour = false;
    }

    public static void setTower(Defence t) {
        tower = t;
    }

    public static void waveIsFinished() {
        Wave wave = new Wave();
        wavelevel++;
        listenemie = wave.start(difficulte*wavelevel);
        System.out.println(listenemie.size());
        Map.setListenemie(listenemie);
        Map.waveIsFinished = true;
        for (Defence t : listdefence){
            t.setlist(listenemie);
        }
    }

    public static void newWaveStart() {
        conteur = 0;
        for (Ennemie e : listenemie) {
            e.start(listenemie, way, map);
        }
    }


    public static void IsArrived() {
        PV -= 1;
        if (PV <= 0){
            gameOver = true;
            pause();
            Map.gameOver();
            if (wavelevel > Bestres){
                save("save.tmp", wavelevel);
            }
        }
    }

    private static int load(String filename) {
        FileInputStream file;
        ObjectInputStream i;
        int BestRes = 0;
        try {
            file = new FileInputStream(filename);
            i = new ObjectInputStream(file);
            BestRes = (int) i.readObject();
        } catch (ClassNotFoundException e1) {
            e1.printStackTrace();
        } catch (FileNotFoundException e1) {
            e1.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }
        return BestRes;
    }

    public static void save(String filename, int BestRes) {
        FileOutputStream file;
        ObjectOutputStream o;
        try {
            file = new FileOutputStream(filename);
            o = new ObjectOutputStream(file);
            o.writeObject(BestRes);
            o.close();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    public static void resetRecord() {
        Bestres = 0;
        save("save.tmp", Bestres);
    }
}
