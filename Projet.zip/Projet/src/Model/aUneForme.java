package Model;

import javafx.scene.shape.Rectangle;

public interface aUneForme {
    Rectangle getForme();
    Rectangle getforme();
}
