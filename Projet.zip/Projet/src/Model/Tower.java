package Model;
import java.util.ArrayList;

import javafx.scene.paint.Color;
import javafx.scene.shape.Line;
import javafx.scene.shape.Polygon;


public class Tower extends Defence implements Runnable {
    private Position position;
    private int attackRange = 200;
    private int attackDamage = 5;
    private int attackSpeed = 50;
    private Thread t;
    private int buildCost = 10;
    private int level = 0;
    private int upgradeCost = 10;
    public ArrayList<Ennemie> listenemie;
    public Polygon triangle = new Polygon();
    public Line laser = new Line();
    private double angle;
    private Ennemie e = null;
    private int play = 0;  //0 = mode play et 1 == pause
    private boolean bool = true;
    private int laserwith = 5;


    public Tower(Position position, ArrayList<Ennemie> list){
        this.position = position;
        listenemie = list;
        t = new Thread(this);
        angle = 0;
    }

    public Position getPosition(){ return position; }

    public void upgrade(){
        level++;
        upgradeCost += 5;
        attackDamage += 5;
        attackRange += 10;
        attackSpeed += 5;
        System.out.println("amélioration réalisée avec succès");
        laserwith += 2;
        if (level == 1) {
            triangle.setFill(Color.RED);
            laser.setFill(Color.BLUE);
        }
        else if (level == 2){
            triangle.setFill(Color.BLUE);
        }
        else if (level == 3){
            triangle.setFill(Color.YELLOW);
        }
    }

    public Polygon getForme(){
        triangle.getPoints().setAll(
                position.getX(), position.getY(),
                position.getX()-50*Math.sin(((30+angle)/180)*Math.PI), position.getY()+50*Math.cos(((30+angle)/180)*Math.PI),
                position.getX()+50*Math.sin(((30-angle)/180)*Math.PI), position.getY()+50*Math.cos(((30-angle)/180)*Math.PI)
        );
        triangle.setFill(Color.WHITE); triangle.setStroke(Color.BLACK);
        return triangle;
    }
    public Line getLaser(){
        laser.setStartX(position.getX());
        laser.setStartY(position.getY());
        laser.setEndX(position.getX());
        laser.setEndY(position.getY());
        laser.setStroke(Color.ORANGE);
        laser.setStrokeWidth(laserwith);
        return laser;
    }

    public Boolean isonTower(Position pos){
        boolean res = false;
        if (position.distance(pos) < 30){
            res = true;
        }
        return res;
    }

    public void shoot(float x, float y){
    }

    @Override
    public void run() {
        while(true) {
            while (bool) {
                System.out.println("okok");
                for (Ennemie ennemie : listenemie) {
                    if (play == 0) {
                        while (ennemie.getHealth() > 0 && position.distance(ennemie.getPosition()) > attackRange) {
                            try {
                                Thread.sleep(15);
                            } catch (InterruptedException ex) {
                                ex.printStackTrace();
                            }
                        }
                        while (ennemie.getHealth() > 0 && position.distance(ennemie.getPosition()) < attackRange) {
                            e = ennemie;
                            if (position.distance(ennemie.getPosition()) < attackRange) {
                                if (play == 1) {
                                    try {
                                        Thread.sleep(50);
                                    } catch (InterruptedException ex) {
                                        ex.printStackTrace();
                                    }
                                } else {
                                    try {
                                        ennemie.looseHealth(attackDamage);
                                        Thread.sleep(attackSpeed);
                                    } catch (InterruptedException e) {
                                        e.printStackTrace();
                                    }
                                }
                            } else {
                                try {
                                    Thread.sleep(attackSpeed);
                                } catch (InterruptedException e) {
                                    e.printStackTrace();
                                }
                            }
                        }
                    } else {
                        try {
                            Thread.sleep(50);
                        } catch (InterruptedException ex) {
                            ex.printStackTrace();
                        }
                    }
                }
                bool = false;
            }
            try {
                Thread.sleep(100);
            } catch (InterruptedException ex) {
                ex.printStackTrace();
            }
        }
    }

    public void start(ArrayList<Ennemie> list) {
        listenemie = list;
        t.start();
    }


    public void update(ArrayList<Ennemie> list) {
        listenemie = list;
        if (e != null) {
            if (position.distance(e.getPosition()) < attackRange && e.getHealth() > 0) {
                angle = position.getAngle(e.getPosition());
                laser.setEndX(e.getPosition().getX()); laser.setEndY(e.getPosition().getY());
            }
            else{
                angle = 0;
                laser.setEndX(position.getX());
                laser.setEndY(position.getY());
            }
            triangle.getPoints().setAll(
                    position.getX(), position.getY(),
                    position.getX() - 50 * Math.sin(((30 + angle) / 180) * Math.PI), position.getY() + 50 * Math.cos(((30 + angle) / 180) * Math.PI),
                    position.getX() + 50 * Math.sin(((30 - angle) / 180) * Math.PI), position.getY() + 50 * Math.cos(((30 - angle) / 180) * Math.PI)
            );
        }
    }


    public void pause(){
        if(play == 1){play = 0;}
        else {play = 1;}
    }

    public int getpriceupgrade() {
        return upgradeCost;
    }

    public int getprice(){return buildCost;}

    public void setlist(ArrayList<Ennemie> list){
        listenemie = list;
        bool = true;
    }
}
