package Model;

public class Coordinate {
}
