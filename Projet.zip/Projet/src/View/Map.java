package View;

import Model.*;
import javafx.animation.AnimationTimer;
import javafx.animation.KeyFrame;
import javafx.animation.Timeline;
import javafx.application.Application;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.scene.Scene;
import javafx.scene.canvas.Canvas;
import javafx.scene.canvas.GraphicsContext;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.*;
import javafx.scene.paint.Color;
import javafx.scene.shape.Line;
import javafx.scene.text.Font;
import javafx.stage.Stage;
import javafx.util.Duration;
import Controller.Test;

import java.io.InputStream;
import java.util.ArrayList;
import java.util.Iterator;

public class Map extends Application implements Iterable<Ennemie> {
    static ArrayList<Ennemie>listenemie = new ArrayList<>();
    static ArrayList<Defence>listdefence = new ArrayList<>();
    Wave wave1 = new Wave();
    public static int gold = 30;
    static int speed = 5;
    static boolean gameOver = false;
    static int height = 34;
    static int width = 50;
    static int cornersize = 20;
    private Timeline timer;
    public static int map;
    public static BorderPane root;
    public boolean posetoursimple = false;
    boolean posetourgele = false;
    boolean upgradetour = false;
    private Defence tower;
    public static boolean waveIsFinished = false;
    public static int play = 0;
    public static Way way;

    public Map(){
        super();
        timer = new Timeline(new KeyFrame(Duration.millis(50), new EventHandler<ActionEvent>() {
            @Override
            public void handle(ActionEvent event) {
                for(Ennemie b: listenemie){
                    b.update();
                }
                for(Defence t : listdefence){
                    t.update(listenemie);
                }
            }
        }));
        timer.setCycleCount(Timeline.INDEFINITE);
        timer.play();

    }



    public static void setListenemie(ArrayList list){
        listenemie = list;
    }



    public static void addTower(Tower tower) {
        listdefence.add(tower);
        root.getChildren().add(tower.getForme());
        root.getChildren().add(tower.getLaser());
    }

    public static void gameOver() {
        gameOver = true;
    }

    @Override
    public void start(Stage stage) {

        try {
            Canvas c = makeCanvas();
            GraphicsContext gc = c.getGraphicsContext2D();
            StackPane canvasHolder = new StackPane();

            Class<?> clazz = this.getClass();
            InputStream input2 = clazz.getResourceAsStream("TestImage.png");
            Image image2 = new Image(input2, 1000, 680, false, true);
            ImageView imageView2 = new ImageView(image2);
            canvasHolder.getChildren().add(imageView2);

            canvasHolder.getChildren().add(c);

            root = new BorderPane(canvasHolder);



            new AnimationTimer() {
                long lastTick = 0;
                public void handle(long now) {
                    if (lastTick == 0) {
                        lastTick = now;
                        tick(gc);
                        return;
                    }
                    if (now - lastTick > 1000000000 / speed) {
                        lastTick = now;
                        tick(gc);
                    }
                }
            }.start();


            for (Line line : way.getWay(map)) {
                root.getChildren().add(line);
            }

            for (Ennemie e : listenemie){
                root.getChildren().add(e.getForme());
            }
            Tower tower = new Tower(new Position(500, 150), listenemie);
            listdefence.add(tower);
            root.getChildren().add(tower.getForme());
            root.getChildren().add(tower.getLaser());
            Test.listdefence.add(tower);
            Scene scene = new Scene(root, width * cornersize, height * cornersize);
            stage.setScene(scene);
            stage.setTitle("Tower Defence Game");
            stage.show();

        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public Canvas makeCanvas(){
        Canvas c = new Canvas(width * cornersize, height * cornersize);
        c.setOnMousePressed( this::mouseClicked );
        c.setOnMouseDragged(this::mouseClicked);
        //  c.setOnMouseReleased(this::mouseClicked);
        return c;
    }

    private void mouseClicked(MouseEvent mouseEvent) {
        int x = (int) mouseEvent.getX();
        int y = (int) mouseEvent.getY();

        if (x < 310 && x > 220 && y < 40) {
            Test.begin();
        }

        else if (x < 490 && x > 430 && y < 40) {
            Test.pause();
        }

        else if(x < 970 && x > 790 && y < 460 && y > 400) {
            if (waveIsFinished){
                for (Ennemie e : listenemie) {
                    root.getChildren().add(e.getForme());
                }
                waveIsFinished = false;
                Test.newWaveStart();
            }
            else {System.out.println("vague pas encore terminée");}
        }


        else if (x < 420 && x > 310 && y > 570) {
            posetoursimple = true;
        }

        else if (x < 720 && x > 610 && y > 570) {
            posetourgele = true;
        }

        else if (x < 130 && x > 10 && y > 550 && upgradetour) {
            Test.upgradetour();
        }

        else if (800 < x && x < 930 && y < 40){
            Test.resetRecord();
        }
        else {
            if (posetoursimple) {
                if (gold >= 10) {
                    Tower u = new Tower(mouseClickedtower(mouseEvent), listenemie);
                    u.start(listenemie);
                    listdefence.add(u);
                    Test.listdefence.add(u);
                    root.getChildren().add(u.getForme());
                    root.getChildren().add(u.getLaser());
                    gold -= 10;
                    upgradetour = false;
                } else {
                    System.out.println("pas assez d'argent poto :( ");
                }
                posetoursimple = false;
            } else if (posetourgele) {
                if (gold >= 15) {
                    TowerGele u = new TowerGele(mouseClickedtower(mouseEvent));
                    listdefence.add(u);
                    root.getChildren().add(u.getForme());
                    gold -= 15;
                } else {
                    System.out.println("pas assez d'argent poto :( ");
                }
                posetourgele = false;
            } else {
                for (Defence t : listdefence) {
                    if (t.isonTower(new Position(x, y))) {
                        upgradetour = true;
                        System.out.println("Tour sélectionnée");
                        tower = t;
                        Test.setTower(t);
                    }
                }
            }
        }

    }

    private Position mouseClickedtower(MouseEvent mouseEvent){
        int x = (int) mouseEvent.getX();
        int y = (int) mouseEvent.getY();
        return new Position(x,y);
    }


    public static void tick(GraphicsContext gc){
        //gc.setFill(Color.GREEN);
        //gc.fillRect(0,0,2000, 2000);


        gc.setFill(Color.WHITE);
        gc.setFont(new Font("",30));
        gc.fillText("gold:" + gold,10,40);

        if (gameOver) {
            System.out.println("bien joué");
            gc.setFill(Color.RED);
            gc.setFont(new Font("",70));
            gc.fillText("GAME OVER", 320,340);
            gc.setFont(new Font("",30));
        }

        gc.setFill(Color.WHITE);
        gc.fillText("Start", 230, 40);

        gc.setFill(Color.WHITE);
        gc.fillText("Tour Simple", 310, 620 );

        gc.setFill(Color.WHITE);
        gc.fillText("Tour Gele", 610, 620 );

        gc.setFill(Color.WHITE);
        gc.fillText("Wave: " + Test.wavelevel, 790, 500);

        if (Test.play == 0) {
            gc.setFill(Color.WHITE);
            gc.fillText("Pause", 420, 40);
        }
        else{
            gc.setFill(Color.WHITE);
            gc.fillText("Play", 670, 40);
        }

        gc.setFill(Color.WHITE);
        gc.fillText("Next Wave", 790, 450);

        gc.setFill(Color.WHITE);
        gc.fillText("Upgrade", 10, 620);

        gc.setFill(Color.WHITE);
        gc.fillText("PV : " + Test.PV, 10, 90);

        gc.setFill(Color.WHITE);
        gc.fillText("Record : " + Test.Bestres, 800, 40);



    }

    public static void create(){
        launch();
    }


    @Override
    public Iterator<Ennemie> iterator() {
        return listenemie.iterator();
    }


}
