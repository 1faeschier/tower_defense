package Model;

public interface aUneVie {
    void looseHealth(int amount);
    int getHealth();
}