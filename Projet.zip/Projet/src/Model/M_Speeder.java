package Model;

public class M_Speeder {

    public M_Speeder(Position positioninit) {
    }
}
