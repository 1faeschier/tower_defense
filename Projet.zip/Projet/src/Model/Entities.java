package Model;

public class Entities {
    private Position localisation;
    private int id;
    private String description;
    private int size;
}
